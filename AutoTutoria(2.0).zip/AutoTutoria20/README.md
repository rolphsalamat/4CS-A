Pa-help sa System Please <3
