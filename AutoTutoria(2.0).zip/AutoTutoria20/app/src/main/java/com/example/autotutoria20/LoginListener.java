package com.example.autotutoria20;

public interface LoginListener {
    void onLoginSuccess(String userName); // Define method in the interface
}