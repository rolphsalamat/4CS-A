package com.example.autotutoria20;

import android.util.Log;

public class x_bkt_algorithm {
    // Parameters for the BKT model
    private double pLearn;
    private double pGuess;
    private double pSlip;
    private double pKnow;

    // 2D arrays for storing scores in Progressive Mode and Free Use Mode
    private double[][] progressiveModeScores;
    private double[][] freeUseModeScores;

    // Constructor
    public x_bkt_algorithm(double pLearn, double pGuess, double pSlip, double pKnow) {
        this.pLearn = pLearn;
        this.pGuess = pGuess;
        this.pSlip = pSlip;
        this.pKnow = pKnow;

        // Initialize arrays based on the number of lessons per module
        progressiveModeScores = new double[][]{
                new double[4], // Module 1: 4 lessons
                new double[1], // Module 2: 1 lesson
                new double[3], // Module 3: 3 lessons
                new double[3], // Module 4: 3 lessons
                new double[3], // Module 5: 3 lessons
                new double[3], // Module 6: 3 lessons
                new double[1], // Module 7: 1 lesson
                new double[3]  // Module 8: 3 lessons
        };

        freeUseModeScores = new double[][]{
                new double[4], // Module 1: 4 lessons
                new double[1], // Module 2: 1 lesson
                new double[3], // Module 3: 3 lessons
                new double[3], // Module 4: 3 lessons
                new double[3], // Module 5: 3 lessons
                new double[3], // Module 6: 3 lessons
                new double[1], // Module 7: 1 lesson
                new double[3]  // Module 8: 3 lessons
        };
    }

    // Method to update scores in a specific mode
//    public void updateScore(int moduleIndex, int lessonIndex, double score, boolean isProgressiveMode) {
//        if (isProgressiveMode) {
//            progressiveModeScores[moduleIndex][lessonIndex] = score;
//        } else {
//            freeUseModeScores[moduleIndex][lessonIndex] = score;
//        }
//        Log.e("updateScore", "Score updated: " + score + " for module " + (moduleIndex + 1) + " lesson " + (lessonIndex + 1));
//    }

    public void updateScore(int moduleIndex, int lessonIndex, double score, boolean isProgressiveMode) {
        if (isProgressiveMode) {
            progressiveModeScores[moduleIndex][lessonIndex] = score;
        } else {
            freeUseModeScores[moduleIndex][lessonIndex] = score;
        }
        Log.e("updateScore", "Score updated: " + score + " for module " + (moduleIndex + 1) + " lesson " + (lessonIndex + 1));
    }


    // Method to retrieve scores from a specific mode
    public double getScore(int moduleIndex, int lessonIndex, boolean isProgressiveMode) {
        if (isProgressiveMode) {
            return progressiveModeScores[moduleIndex][lessonIndex];
        } else {
            return freeUseModeScores[moduleIndex][lessonIndex];
        }
    }

    // Existing methods for BKT model
    public void updateKnowledge(boolean correct) {
        double pCorrect = pKnow * (1 - pSlip) + (1 - pKnow) * pGuess;
        if (correct) {
            pKnow = (pKnow * (1 - pSlip)) / pCorrect;
        } else {
            pKnow = (pKnow * pSlip) / (1 - pCorrect);
        }
        pKnow = pKnow + (1 - pKnow) * pLearn;
        Log.e("updateKnowledge", "pKnow: " + pKnow);
    }

    public boolean knowsSkill() {
        return pKnow > 0.95;
    }

    public double getKnowledgeProbability() {
        return pKnow;
    }

    public void logScores() {
        // Log Progressive Mode scores
        for (int i = 0; i < progressiveModeScores.length; i++) {
            StringBuilder sb = new StringBuilder();
            sb.append("Progressive Mode, Module ").append(i + 1).append(": [");
            for (int j = 0; j < progressiveModeScores[i].length; j++) {
                sb.append(progressiveModeScores[i][j]);
                if (j < progressiveModeScores[i].length - 1) {
                    sb.append(", ");
                }
            }
            sb.append("]");
            Log.e("BKT Scores", sb.toString());
        }

        // Log Free Use Mode scores
        for (int i = 0; i < freeUseModeScores.length; i++) {
            StringBuilder sb = new StringBuilder();
            sb.append("Free Use Mode, Module ").append(i + 1).append(": [");
            for (int j = 0; j < freeUseModeScores[i].length; j++) {
                sb.append(freeUseModeScores[i][j]);
                if (j < freeUseModeScores[i].length - 1) {
                    sb.append(", ");
                }
            }
            sb.append("]");
            Log.e("BKT Scores", sb.toString());
        }
    }

}
