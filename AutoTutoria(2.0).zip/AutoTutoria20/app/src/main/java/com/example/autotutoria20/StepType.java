package com.example.autotutoria20;

public enum StepType {
    PRE_TEST,
    POST_TEST,
    VIDEO,
    TEXT
}
