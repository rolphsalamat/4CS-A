package com.example.autotutoria20;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.autotutoria20.R;

public class f_text_lesson extends Fragment {
    private static final String ARG_KEY = "key";

    private TextView titleTextView;
    private TextView contentTextView_1, contentTextView_2, contentTextView_3;
    private LinearLayout nextButton;
    private int currentStep = 0; // Track which content is currently shown

    // Initialize arrays for step counts
    private int[] module1Steps = {3, 2, 2, 2};
    private int[] module2Steps = {2};
    private int[] module3Steps = {2, 2, 2};
    private int[] module4Steps = {2, 2, 2};
    private int[] module5Steps = {2, 2, 2};
    private int[] module6Steps = {2, 2, 2};
    private int[] module7Steps = {2};
    private int[] module8Steps = {2, 2, 2};

    private OnNextButtonClickListener callback;
    private int totalSteps = 2; // Default total steps

    public static f_text_lesson newInstance(String key) {
        f_text_lesson fragment = new f_text_lesson();
        Bundle args = new Bundle();
        args.putString(ARG_KEY, key);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_text, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        titleTextView = view.findViewById(R.id.text_lesson_title);
        contentTextView_1 = view.findViewById(R.id.text_lesson_content_1);
        contentTextView_2 = view.findViewById(R.id.text_lesson_content_2);
        contentTextView_3 = view.findViewById(R.id.text_lesson_content_3);
        nextButton = view.findViewById(R.id.next_button);

        if (getArguments() != null) {
            String key = getArguments().getString(ARG_KEY);
            if (key != null && !key.isEmpty()) {
                setTotalStepsForKey(key); // Set total steps based on the key
                loadTextContentForKey(key);
            }
        }

        // Initially hide all content views except the first one
        contentTextView_1.setVisibility(View.VISIBLE);
        contentTextView_2.setVisibility(View.GONE);
        contentTextView_3.setVisibility(View.GONE);

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleNextButtonClick();
            }
        });
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        // Ensure that the host activity implements the callback interface
        try {
            callback = (OnNextButtonClickListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement OnNextButtonClickListener");
        }
    }

    // Define an interface to communicate with the container activity
    public interface OnNextButtonClickListener {
        void onNextButtonClicked();
    }

    private void setTotalStepsForKey(String key) {
        switch (key) {
            // Module 1
            case "M1_Lesson 1":
                totalSteps = module1Steps[0];
                break;
            case "M1_Lesson 2":
                totalSteps = module1Steps[1];
                break;
            case "M1_Lesson 3":
                totalSteps = module1Steps[2];
                break;
            case "M1_Lesson 4":
                totalSteps = module1Steps[3];
                break;

            // Module 2
            case "M2_Lesson 1":
                totalSteps = module2Steps[0];
                break;

            // Module 3
            case "M3_Lesson 1":
                totalSteps = module3Steps[0];
                break;
            case "M3_Lesson 2":
                totalSteps = module3Steps[1];
                break;
            case "M3_Lesson 3":
                totalSteps = module3Steps[2];
                break;

            // Module 4
            case "M4_Lesson 1":
                totalSteps = module4Steps[0];
                break;
            case "M4_Lesson 2":
                totalSteps = module4Steps[1];
                break;
            case "M4_Lesson 3":
                totalSteps = module4Steps[2];
                break;

            // Module 5
            case "M5_Lesson 1":
                totalSteps = module5Steps[0];
                break;
            case "M5_Lesson 2":
                totalSteps = module5Steps[1];
                break;
            case "M5_Lesson 3":
                totalSteps = module5Steps[2];
                break;

            // Module 6
            case "M6_Lesson 1":
                totalSteps = module6Steps[0];
                break;
            case "M6_Lesson 2":
                totalSteps = module6Steps[1];
                break;
            case "M6_Lesson 3":
                totalSteps = module6Steps[2];
                break;

            // Module 7
            case "M7_Lesson 1":
                totalSteps = module7Steps[0];
                break;

            // Module 8
            case "M8_Lesson 1":
                totalSteps = module8Steps[0];
                break;
            case "M8_Lesson 2":
                totalSteps = module8Steps[1];
                break;
            case "M8_Lesson 3":
                totalSteps = module8Steps[2];
                break;

            // Fallback/default
            default:
                totalSteps = 2; // Fallback default steps
                break;
        }
    }


    // In handleNextButtonClick, call the callback when appropriate
    private void handleNextButtonClick() {
        currentStep++;
        if (currentStep < totalSteps) {
            showNextStep(currentStep);
        } else {
            Log.e("f_text_lesson.java", "tapos na, pero wala nang gagawin kasi inadjust ko na yung pinaka main layout");
//            updateNextButtonForFinalAction();
            if (callback != null) {
                callback.onNextButtonClicked();  // Notify the activity that the next button was clicked
            }
        }
    }

    private void showNextStep(int step) {
        switch (step) {
            case 1:
                contentTextView_2.setVisibility(View.VISIBLE);
                break;
            case 2:
                contentTextView_3.setVisibility(View.VISIBLE);
                break;
        }
    }

//    private void updateNextButtonForFinalAction() {
//        nextButton.setText("Next");
//        nextButton.setTextColor(getResources().getColor(R.color.black));
//        nextButton.setBackgroundResource(android.R.color.darker_gray);
//        nextButton.setAllCaps(true);
//    }

    private void loadTextContentForKey(String key) {
        switch (key) {
            // Module 1
            case "M1_Lesson 1":
                titleTextView.setText(R.string.module1_1_title);
                contentTextView_1.setText(R.string.module1_1_content_1);
                contentTextView_2.setText(R.string.module1_1_content_2);
                contentTextView_3.setText(R.string.module1_1_content_3);
                break;
            case "M1_Lesson 2":
                titleTextView.setText(R.string.module1_2_title);
                contentTextView_1.setText(R.string.module1_2_content_1);
                contentTextView_2.setText(R.string.module1_2_content_2);
                contentTextView_3.setText(R.string.module1_2_content_3);
                break;
            case "M1_Lesson 3":
                titleTextView.setText(R.string.module1_3_title);
                contentTextView_1.setText(R.string.module1_3_content_1);
                contentTextView_2.setText(R.string.module1_3_content_2);
                contentTextView_3.setText(R.string.module1_3_content_3);
                break;
            case "M1_Lesson 4":
                titleTextView.setText(R.string.module1_4_title);
                contentTextView_1.setText(R.string.module1_4_content_1);
                contentTextView_2.setText(R.string.module1_4_content_2);
                contentTextView_3.setText(R.string.module1_4_content_3);
                break;

            // Module 2
            case "M2_Lesson 1":
                titleTextView.setText(R.string.module2_1_title);
                contentTextView_1.setText(R.string.module2_1_content_1);
                contentTextView_2.setText(R.string.module2_1_content_2);
                contentTextView_3.setText(R.string.module2_1_content_3);
                break;

            // Module 3
            case "M3_Lesson 1":
                titleTextView.setText(R.string.module3_1_title);
                contentTextView_1.setText(R.string.module3_1_content_1);
                contentTextView_2.setText(R.string.module3_1_content_2);
                contentTextView_3.setText(R.string.module3_1_content_3);
                break;
            case "M3_Lesson 2":
                titleTextView.setText(R.string.module3_2_title);
                contentTextView_1.setText(R.string.module3_2_content_1);
                contentTextView_2.setText(R.string.module3_2_content_2);
                contentTextView_3.setText(R.string.module3_2_content_3);
                break;
            case "M3_Lesson 3":
                titleTextView.setText(R.string.module3_3_title);
                contentTextView_1.setText(R.string.module3_3_content_1);
                contentTextView_2.setText(R.string.module3_3_content_2);
                contentTextView_3.setText(R.string.module3_3_content_3);
                break;

            // Module 4
            case "M4_Lesson 1":
                titleTextView.setText(R.string.module4_1_title);
                contentTextView_1.setText(R.string.module4_1_content_1);
                contentTextView_2.setText(R.string.module4_1_content_2);
                contentTextView_3.setText(R.string.module4_1_content_3);
                break;
            case "M4_Lesson 2":
                titleTextView.setText(R.string.module4_2_title);
                contentTextView_1.setText(R.string.module4_2_content_1);
                contentTextView_2.setText(R.string.module4_2_content_2);
                contentTextView_3.setText(R.string.module4_2_content_3);
                break;
            case "M4_Lesson 3":
                titleTextView.setText(R.string.module4_3_title);
                contentTextView_1.setText(R.string.module4_3_content_1);
                contentTextView_2.setText(R.string.module4_3_content_2);
                contentTextView_3.setText(R.string.module4_3_content_3);
                break;

            // Module 5
            case "M5_Lesson 1":
                titleTextView.setText(R.string.module5_1_title);
                contentTextView_1.setText(R.string.module5_1_content_1);
                contentTextView_2.setText(R.string.module5_1_content_2);
                contentTextView_3.setText(R.string.module5_1_content_3);
                break;
            case "M5_Lesson 2":
                titleTextView.setText(R.string.module5_2_title);
                contentTextView_1.setText(R.string.module5_2_content_1);
                contentTextView_2.setText(R.string.module5_2_content_2);
                contentTextView_3.setText(R.string.module5_2_content_3);
                break;
            case "M5_Lesson 3":
                titleTextView.setText(R.string.module5_3_title);
                contentTextView_1.setText(R.string.module5_3_content_1);
                contentTextView_2.setText(R.string.module5_3_content_2);
                contentTextView_3.setText(R.string.module5_3_content_3);
                break;

            // Module 6
            case "M6_Lesson 1":
                titleTextView.setText(R.string.module6_1_title);
                contentTextView_1.setText(R.string.module6_1_content_1);
                contentTextView_2.setText(R.string.module6_1_content_2);
                contentTextView_3.setText(R.string.module6_1_content_3);
                break;
            case "M6_Lesson 2":
                titleTextView.setText(R.string.module6_2_title);
                contentTextView_1.setText(R.string.module6_2_content_1);
                contentTextView_2.setText(R.string.module6_2_content_2);
                contentTextView_3.setText(R.string.module6_2_content_3);
                break;
            case "M6_Lesson 3":
                titleTextView.setText(R.string.module6_3_title);
                contentTextView_1.setText(R.string.module6_3_content_1);
                contentTextView_2.setText(R.string.module6_3_content_2);
                contentTextView_3.setText(R.string.module6_3_content_3);
                break;

            // Module 7
            case "M7_Lesson 1":
                titleTextView.setText(R.string.module7_1_title);
                contentTextView_1.setText(R.string.module7_1_content_1);
                contentTextView_2.setText(R.string.module7_1_content_2);
                contentTextView_3.setText(R.string.module7_1_content_3);
                break;

            // Module 8
            case "M8_Lesson 1":
                titleTextView.setText(R.string.module8_1_title);
                contentTextView_1.setText(R.string.module8_1_content_1);
                contentTextView_2.setText(R.string.module8_1_content_2);
                contentTextView_3.setText(R.string.module8_1_content_3);
                break;
            case "M8_Lesson 2":
                titleTextView.setText(R.string.module8_2_title);
                contentTextView_1.setText(R.string.module8_2_content_1);
                contentTextView_2.setText(R.string.module8_2_content_2);
                contentTextView_3.setText(R.string.module8_2_content_3);
                break;
            case "M8_Lesson 3":
                titleTextView.setText(R.string.module8_3_title);
                contentTextView_1.setText(R.string.module8_3_content_1);
                contentTextView_2.setText(R.string.module8_3_content_2);
                contentTextView_3.setText(R.string.module8_3_content_3);
                break;

            // Fallback case
            default:
                titleTextView.setText("Default Title");
                contentTextView_1.setText("Default Text 1");
                contentTextView_2.setText("Default Text 2");
                contentTextView_3.setText("Default Text 3");
                break;
        }
    }

}
